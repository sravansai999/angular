export class Student {


    id:number;
    age:String;
    gender:String;
    name:String;
    mobile:String;

}
